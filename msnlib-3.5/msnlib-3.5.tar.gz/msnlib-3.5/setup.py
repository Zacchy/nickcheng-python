
from distutils.core import setup

setup(name="msnlib",
	version="3.5",
	description="MSN Messenger Library and Client",
	author="Alberto Bertogli",
	author_email="albertogli@telpin.com.ar",
	url="http://users.auriga.wearlab.de/~alb/msnlib",
	py_modules=['msnlib', 'msncb'],
)
									 
